#include "async_task.h"

#include "async_orchestrator.h"

namespace hdn
{
	void ITask::Complete()
	{
		// Notify all the tasks that depend on this one, the let the dependencies enqueue themselve in the orchestrator
		for (ITask* task : m_OutDep)
		{
			HASSERT_TASK(task);
			task->Notify(this);
		}
	}

	const char* ITask::GetName()
	{
		return "ITask";
	}

	void ITask::AddInDependency(ITask* task)
	{
		m_InDep.push_back(task);
	}

	void ITask::AddOutDependency(ITask* task)
	{
		m_OutDep.push_back(task);
	}

	void ITask::Notify(ITask* task)
	{
		if (AreInDepResolved())
		{
			AsyncOrchestrator::Get().EnqueueTask(this);
		}
	}

	bool ITask::AreInDepResolved()
	{
		for (ITask* task : m_OutDep)
		{
			HASSERT_TASK(task);
			if (!task->Completed())
			{
				return false;
			}
		}
		return true;
	}
}