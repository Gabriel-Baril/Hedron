#pragma once

#include "core/core.h"

#define HASSERT_TASK(task) HASSERT(task, "Task cannot be null!")

namespace hdn
{
	class ITask
	{
	public:

		virtual ~ITask() = default;

		virtual void Execute() = 0;
		virtual bool Completed() const = 0;
		virtual void Complete();

		// Both Priority and Complexity are additive property, P(n) + P(m) = P(n+m)
		virtual u8 Priority() const { return 1; }
		virtual u8 Complexity() const { return 1; }
		
		// TODO: Remove symbols from release build
		virtual const char* GetName();

		void AddInDependency(ITask* task);
		void AddOutDependency(ITask* task);

		// This function is called each time a task is completed to let the out dependencies that the task is completed
		virtual void Notify(ITask* task);
	private:
		bool AreInDepResolved();
	private:
		TVector<ITask*> m_InDep;
		TVector<ITask*> m_OutDep;
		// ITask* m_Parent;
	};
}