#include "async_task_queue.h"

#include "async_orchestrator.h"

namespace hdn
{
	ITaskQueue::ITaskQueue()
	{
	}

	void ITaskQueue::AddTask(ITask* task)
	{
		if (!m_TaskQueue.empty())
		{
			ITask* previousTask = m_TaskQueue.front();

			previousTask->AddOutDependency(task);
			task->AddInDependency(task);
		}
		m_TaskQueue.push(task);
	}

	bool ITaskQueue::Completed() const
	{
		return m_TaskQueue.empty();
	}

	void ITaskQueue::Execute()
	{
		ITask* firstTask = m_TaskQueue.front();

		// We only need to queue the first task, the subsequent tasks will automatically register themselve once their in-dependencies are Completed()
		AsyncOrchestrator::Get().EnqueueTask(firstTask);
	}
}
